import pdb
import csv
import collections
import string
import re
from ltp import LTP
import os
import json
nlp = LTP()

class Parse:
    def cut_sent(self, doc):
        sen = re.sub('([。！!？\?])([^”’])', r"\1\n\2", doc.rstrip())  # 单字符断句符
        return sen.split('\n')

    def process_data(self, path):
        processed = []
        f = open('%s/raw_data.txt'%path, 'r', encoding='utf-8')
        for data in f:
            print(len(processed), end='\r')
            text = data.rstrip().replace('\ufeff', '')
            if text == '':
                continue
            # 将文档分句后，针对句子处理
            doc = self.cut_sent(text)
            seg, hidden = nlp.seg(doc)
            pos = nlp.pos(hidden)
            dep = nlp.dep(hidden)
            seg_list, pos_list, dep_list = [], [], []

            for s, p, d in zip(seg, pos, dep):
                seg_list.append(' '.join(s))
                pos_list.append(' '.join(p))
                dep_list.append('|'.join(['{} {} {}'.format(a, b, r) for (a, b, r) in d]))

            processed.append({
                'text': '<sentence>'.join(seg_list),
                'postag': '<sentence>'.join(pos_list),
                'dependency': '<sentence>'.join(dep_list),
                })
            
        print('total %i samples'%len(processed))
        json.dump(processed, open('%s/data.json'%path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
