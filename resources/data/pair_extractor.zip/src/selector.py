import pdb
import json
from collections import defaultdict

class SentenceSelector:
    def __init__(self, path):
        self.data_path = path
        self.database_target = json.load(open('{}/database_target.json'.format(self.data_path), 'r', encoding='utf-8'))
        self.database_pair = json.load(open('{}/database_pair.json'.format(self.data_path), 'r', encoding='utf-8'))
        self.database_sentence = json.load(open('{}/database_sentence.json'.format(self.data_path), 'r', encoding='utf-8'))

    # 输出语料中包含target的所有句子，每个样本是一个句子，以及该句子中提及的target
    def select_by_target(self):
        fr = open('{}/true_target.txt'.format(self.data_path), 'r', encoding='utf-8')
        targets = set()
        for line in fr:
            targets.add(json.loads(line.rstrip())['target'])
        target_in_sentence = defaultdict(list) # {sentence_id1: [target1, target2, ...], sentence_id2: [target1, target2, ...]}
        for t in self.database_target:
            if t in targets:
                for s in self.database_target[t]['sentence']:
                    target_in_sentence[s].append(t)

        sentence_by_target = []
        for s in target_in_sentence:
            sentence_by_target.append({'sentence': self.database_sentence[s],
                                       'target': target_in_sentence[s]
                                      })
        json.dump(sentence_by_target, open('{}/sentence_containing_targets.json'.format(self.data_path), 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    # 输出语料中包含pair的所有句子，每个样本是一个句子，以及该句子中提及的pair
    def select_by_pair(self):
        fr = open('{}/true_pair.txt'.format(self.data_path), 'r', encoding='utf-8')
        pairs = set()
        for line in fr:
            pairs.add(json.loads(line.rstrip())['pair'])
        pair_in_sentence = defaultdict(list) # {sentence_id1: [pair1, pair2, ...], sentence_id2: [pair1, pair2, ...]}
        for p in self.database_pair:
            if p in pairs:
                for s in self.database_pair[p]['sentence']:
                    pair_in_sentence[s].append(p)

        sentence_by_pair = []
        for s in pair_in_sentence:
            sentence_by_pair.append({'sentence': self.database_sentence[s],
                                       'pair': pair_in_sentence[s]
                                      })
        json.dump(sentence_by_pair, open('{}/sentence_containing_pairs.json'.format(self.data_path), 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    # 对于一个句子，只要其包含pair的target和opinion word，即使两者不存在依存关系，仍将其输出。可用于标注具有长程依赖或复杂依存关系的搭配。
    def select_by_possible_pair(self):
        fr = open('{}/true_pair.txt'.format(self.data_path), 'r', encoding='utf-8')
        pairs = set()
        for line in fr:
            pairs.add(json.loads(line.rstrip())['pair'])
        pair_in_sentence = defaultdict(list)
        