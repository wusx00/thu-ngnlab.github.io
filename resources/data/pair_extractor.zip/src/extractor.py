import pdb
import csv
import collections
import string
import re
import os
import numpy as np
import pickle as pkl
from sklearn import metrics
import scipy.spatial.distance as ssd
import scipy.linalg as LA
from sklearn import svm
import argparse
import json
from gensim.models.keyedvectors import KeyedVectors
from collections import defaultdict

# 从句法解析后的数据中，抽取候选组合与候选评价对象，存入文件
class Extractor:
    def __init__(self, path):
        self.data_path = path
        self.initialize_variables()

    def initialize_variables(self):
        # 存储抽取结果
        self.database_sentence = []
        self.database_target = {}
        self.database_pair = {}
        self.word_pos = defaultdict(dict)

    def extract_candidates_from_corpus(self, data, word2vec=None):
        # 解析工具存在噪声，有时候对词语的词性判断不准，因此先统计每个词语的所有词性，仅保留频率最高的词性
        for d in data:
            for sen, pos in zip(d['text'].split('<sentence>'), d['postag'].split('<sentence>')):
                sen, pos = sen.split(), pos.split()
                for s, p in zip(sen, pos):
                    if p not in self.word_pos[s]:
                        self.word_pos[s][p] = 1
                    else:
                        self.word_pos[s][p] += 1
        # 保留频率最高的词性
        for w in self.word_pos:
            p = sorted(self.word_pos[w].keys(), key=lambda x: self.word_pos[w][x])[-1]
            self.word_pos[w] = p

        for d in data:
            for sen, pos, dep in zip(d['text'].split('<sentence>'), d['postag'].split('<sentence>'), d['dependency'].split('<sentence>')):
                sen, pos, dep = sen.split(), pos.split(), dep.split('|')
                if len(sen) == 0:
                    continue
                # 图的每个节点是一个词语，边是依存关系类型
                graph, edge = self.decode_dep(dep)
                # 为简便，存储所有句子，其实不用全部存储，可根据需要仅存储满足条件的句子
                self.database_sentence.append(' '.join(sen))
                index_sentence = len(self.database_sentence) - 1
                for i in range(len(sen)):
                    # 剔除名词和形容词（后续工作如果要构建种类更丰富的二元组，可以修改此处的条件）
                    if self.word_pos[sen[i]] not in ['a', 'n']:
                        continue
                    if i not in graph or graph[i] == -1:
                        continue
                    j = graph[i]

                    # 若第i个词和第j个词符合特定模式，则构成一组对象-情感词组合。该策略非常简单，可进一步优化
                    pair = self.extract_pair(sen, pos, i, j) + self.extract_pair(sen, pos, j, i)
                    if pair:
                        target, opinion = pair
                        # 滤除低频对象
                        if word2vec != None and target not in word2vec.wv:
                            continue
                        # 按 target 为关键字存储
                        if target not in self.database_target:
                            self.database_target[target] = {
                                                            'frequency': 1, 
                                                            'pair': set([' '.join(pair)]),
                                                            'sentence': [],
                                                            'importance_score': 0 # 暂未计算
                                                            }
                        else:
                            self.database_target[target]['frequency'] += 1
                            self.database_target[target]['pair'].add(' '.join(pair))
                        # 按 pair 为关键字存储
                        if ' '.join(pair) not in self.database_pair:
                            self.database_pair[' '.join(pair)] = {
                                                                  'frequency': 1, 
                                                                  'sentence': set()
                                                                  }
                        else:
                            self.database_pair[' '.join(pair)]['frequency'] += 1
                            self.database_pair[' '.join(pair)]['sentence'].add(index_sentence)

        # 将 set 转换以便存储
        for target in self.database_target:
            self.database_target[target]['pair'] = list(self.database_target[target]['pair'])
        for pair in self.database_pair:
            self.database_pair[pair]['sentence'] = list(self.database_pair[pair]['sentence'])

        # 建立target和句子的索引，有些句子没有pair但有target
        for i, sentence in enumerate(self.database_sentence): 
            word_in_sentence = set()
            for word in sentence.split(' '):
                if word in self.database_target and word not in word_in_sentence:
                    self.database_target[word]['sentence'].append(i)
                    word_in_sentence.add(word)
        for word in self.database_target:
            self.database_target[word]['sentence'] = list(self.database_target[word]['sentence'])

        # 按 pair 在语料中出现的频率排序，可更换其他排序方式
        self.sort_target = sorted(self.database_target.keys(), key=lambda x: self.database_target[x]['frequency'], reverse=True)
        self.sort_pair = sorted(self.database_pair.keys(), key=lambda x: self.database_pair[x]['frequency'], reverse=True)

    def extract_pair(self, sen, pos, i, j):
        if pos[i] == 'n' and pos[j] == 'a' and self.word_pos[sen[i]] == 'n' and self.word_pos[sen[j]] == 'a':
            return [sen[i], sen[j]]
        return []

    def decode_dep(self, dep):
        graph = collections.defaultdict()
        edge = collections.defaultdict()
        edge_rev = collections.defaultdict(list)
        for rel in dep:
            start, end, rel_type = rel.split()
            start, end = int(start), int(end)
            graph[start-1] = end-1
            edge[start-1] = rel_type
            edge_rev[end-1].append(start-1)
        return graph, edge

    def run(self, filter_freq_target=5, filter_freq_pair=3):
        data = json.load(open('{}/data.json'.format(self.data_path), 'r', encoding='utf-8'))
        #word2vec = KeyedVectors.load('%s/word2vec'%self.data_path)
        self.extract_candidates_from_corpus(data)
        self.database_target = {t: self.database_target[t] for t in self.database_target if self.database_target[t]['frequency'] > filter_freq_target}
        self.database_pair = {p: self.database_pair[p] for p in self.database_pair if (p.split()[0] in self.database_target and self.database_pair[p]['frequency'] > filter_freq_pair)}
        
        # database_target以target为关键字存储抽取结果，database_pair以pair为关键字存储抽取结果，sentence为句子列表
        json.dump(self.database_target, open('{}/database_target.json'.format(self.data_path), 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        json.dump(self.database_pair, open('{}/database_pair.json'.format(self.data_path), 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        json.dump(self.database_sentence, open('{}/database_sentence.json'.format(self.data_path), 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

        # 按频率存储候选对象和搭配，供标注
        ft = open('{}/target_list.txt'.format(self.data_path), 'w', encoding='utf-8')
        fp = open('{}/pair_list.txt'.format(self.data_path), 'w', encoding='utf-8')
        target_list, pair_list = [], []

        for t in self.sort_target:
            if t not in self.database_target: continue
            item = {'target': t, 
                    'num of sentence': len(self.database_target[t]['sentence']),
                    'num of pair': len(self.database_target[t]['pair']),
                    'frequency': self.database_target[t]['frequency']
                    }
            ft.write(json.dumps(item, ensure_ascii=False))
            ft.write('\n')

        for p in self.sort_pair:
            if p not in self.database_pair: continue
            item = {'pair': p, 
                    'num of sentence': len(self.database_pair[p]['sentence']),
                    'frequency': self.database_pair[p]['frequency']
                    }
            fp.write(json.dumps(item, ensure_ascii=False))
            fp.write('\n')

        ft.close()
        fp.close()