## Requirements
* python: 3.6
* ltp: 4.1.3
* scipy: 1.1.0
* numpy: 1.17.4

## 代码功能
* 对于任意领域无标注语料，基于句法解析结果和人工设置的规则匹配，抽取语料中可能存在的评价对象和情感词。
* 此代码仅适合语料结构化情感信息的初步抽取，旨在降低对数据格式的依赖，提升代码的迁移性。更细粒度、更丰富的表达形式，还需手动标注特定任务的标签数据。另外，该代码能够用于过滤无效样本（如不包含某个对象的评论），提升标注效率。

## 数据格式
见样例`data/酒店/raw_data.txt`，每行对应一条评论。

## 使用说明
1. 仅有原始数据时，运行`python run.py --parse`进行预处理，生成`data.json`。
2. 运行`python run.py --extract`抽取候选target和pair，及其与对应的句子的索引，存储于`database_pair.json/database_sentence.json/database_target.json`。候选target和pair列表存储于`target_list.txt`和`pair_list.txt`。
3. 将`target_list.txt`和`pair_list.txt`分别更名为`true_target.txt`和`true_pair.txt`，并进行标注。标注方法：直接将无关的target和pair所在行删除即可。排序靠前的target和pair质量较好，可滤除排序靠后的样本。
4. 根据标注后的target和pair筛选句子，运行`python run.py --select_by_target`或`python run.py --select_by_pair`，滤除无关评论。
