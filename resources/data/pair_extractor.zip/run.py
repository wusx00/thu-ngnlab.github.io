from src.process import Parse
from src.extractor import Extractor
from src.selector import SentenceSelector
import pickle as pkl
import pdb
import argparse

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--path', type=str, default='data/热水器')
    parser.add_argument('--path_embedding', type=str, default="C:/Users/wusx11/Documents/Wsx/sgns.wiki.word") # 代码中暂未用到
    parser.add_argument('--parse', action='store_true', help='仅有原始数据，需要预处理时，传此参数')
    parser.add_argument('--extract', action='store_true', help='已完成预处理，需抽取候选对象和搭配时，传此参数')
    parser.add_argument('--select_by_target', action='store_true', help='已标注真实对象，需筛选对应的句子时，传此参数')
    parser.add_argument('--select_by_pair', action='store_true', help='已标注真实搭配，需筛选对应的句子时，传此参数')
    args = parser.parse_args()

    if args.parse: # 新数据，需要预处理时执行此操作
        parser = Parse()
        print('start parsing corpus %s'%args.path)
        parser.process_data(args.path)
    if args.extract: # 预处理完成，抽取对象时执行此操作
        print('start extracting candidate targets and pairs')
        candidate = Extractor(args.path)
        # 将抽取的对象、组合及与句子的对应索引存储到相应文件中
        candidate.run()
        print('info: target %i, pair %i, sentence %i'%(len(candidate.database_target), len(candidate.database_pair), len(candidate.database_sentence)))
    if args.select_by_target: # 基于标注的评价对象过滤原始语料
        selector = SentenceSelector(args.path)
        selector.select_by_target()
    if args.select_by_pair: # 基于标注的搭配过滤原始语料
        selector = SentenceSelector(args.path)
        selector.select_by_pair()